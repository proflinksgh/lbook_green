<?php
class amwork_controller extends route
{
	private $user_tag;
	private $user_initing;
	private $date_composer;
	private $id, $product_name, $date, $deposits, $subscription, $withdrawals, $dob, $gender, $interest, $contact1, $contact2, $email, $country, $region, $city, $occupation, $identification, $idnumber, $conn, $date_created, $account_number;

	  function __construct()
	{
	    $this->user_tag = $this->model('master_class');
		$this->user_initing = $this->model('extend_function');
		$this->date_composer = $this->user_initing->timer;
		$this->conn = new master_class();
		$this->user = new extend_function();
	}
	
	public function index()
	{
	    $this->mature();
	}
       function mature()
		{
		    
		extract($_POST);
		$db = $this->user_initing;
		$msg = array();
		   
		$matured= $this->user->getAllData("SELECT ct.ID, FIRSTNAME, pt.NAME, LASTNAME, OTHERNAME, atb.DATE_MODIFIED, ACCOUNT_NO, NAME, SUBSCRIPTION from client_tb ct JOIN account_tb atb ON ct.CODE = atb.CLIENT_ID JOIN product_tb pt ON pt.CODE = atb.PRODUCT_ID WHERE atb.PRODUCT_ID = '2' AND ACC_STATUS = '1' AND atb.CCODE = ".$_COOKIE["ccode"]."");
		
		if($matured != 0){
		foreach($matured as $row)
        {
            $this->subscription = $row['SUBSCRIPTION'];
            if($this->subscription == ''||$this->subscription == null||$this->subscription == "null"){
 			    $this->subscription = "N/A";
 			}else if($this->subscription == '30'){
 			    $this->subscription = '1 Month';
 			}else if($this->subscription == '90'){
 			    $this->subscription = '3 Months';
 			}else if($this->subscription == '180'){
 			    $this->subscription = '6 Months';
 			}else if($this->subscription == '270'){
 			    $this->subscription = '9 Months';
 			}else if($this->subscription == '360'){
 			    $this->subscription = '1 year';
 			}else if($this->subscription == '720'){
 			    $this->subscription = '2 years';
 			}else if($this->subscription == '1080'){
 			    $this->subscription = '3 years';
 			}
            
            
         $msg[] = array("id" => $row['ID'], "name" => $row['FIRSTNAME']." ".$row['LASTNAME']." ".$row['OTHERNAME'], "subscription" => $this->subscription, "account_number" => $row['ACCOUNT_NO'], "matured_date"=>$row['DATE_MODIFIED'], "product"=>$row['NAME']);
        }
		   
		echo json_encode($msg);
	}
  }
}
?>