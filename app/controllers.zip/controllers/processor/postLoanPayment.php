<?php
class amwork_controller extends route
{
	private $user_tag, $username;
	private $user_initing;
	private $date_composer;
	private $conn, $id, $fee, $min_amount, $max_amount;

	function __construct()
	{
	    $this->user_tag = $this->model('master_class');
		$this->user_initing = $this->model('extend_function');
		$this->date_composer = $this->user_initing->timer;
		$this->conn = new master_class();
		$this->user = new extend_function();
	}
	
		public function index()
	{
        $this->post_loan();
	}

	function post_loan()
	   {
		extract($_POST);
		    $db = $this->user_initing;
			$accno = $db->cleanInput($accno);
    		$amount = $db->cleanInput($amount);
    		$loanid=$db->get_data_here_value("SELECT ID FROM loan_tb WHERE ACCOUNT_NO='$accno'","ID");
		    $customerid=$db->get_data_here_value("SELECT id FROM loanreg_tb WHERE code='$accno'","id");
    		$user = $_SESSION['id'];
    		if(isset($_SESSION['id'])){
    		   $params = array($customerid, $loanid, $amount, $user, $db->date_normal(), $db->date_created(), $db->date_created(), $_COOKIE['ccode'], $db->hcode());
        	   $query = "INSERT INTO loan_payment (CUSTOMERID, LOANID, AMOUNT, POSTED_BY, DATE_NORMAL, DATE_CREATED,DATE_MODIFIED, CCODE, HCODE) VALUES (?,?,?,?,?,?,?,?,?)";
               $insert_ = $db->InsertRecords($query, $params);	
               if($insert_>0){
               	echo json_encode(array("status"=>"success"));
               }else{
               	echo json_encode(array("status"=>"failed"));
               }
    	 }else{
    	 	echo json_encode(array("status"=>"expire"));
    	 }
	   }
    }
?>