 <form action="" method="POST" id="pending_form">
     <style>
     
     .icon-layout{
         color:green;
        display:inline-block;
        margin: 5px;
  
  
     }
     
     .text-layout{
         
         text-align:center;
     }
     </style>
     
 <!-- page content -->

        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
            </div>
              
            <div class="clearfix"></div>
          
            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <!--div class="x_panel"-->
                 
                  <div class="x_content">
                  <!--put your page content starts here-->

              <!--    <div class="col-md-12 col-sm-12 ">-->
              <!--  <div class="x_panel">-->
              <!--    <div class="x_title">-->
              <!--      <div class="clearfix"></div>-->
              <!--    </div>-->
              <!--    <div class="x_content">-->
              <!--    <div class="row">-->
              <!--            <div class="col-sm-12">-->
                              
              <!--                  <div class="card-box table-responsive">-->
              <!--                  <div class="item form-group">-->
              <!--                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name"><b>Account number </b><span class="required">*</span>-->
              <!--                      </label>-->
              <!--                      <div class="alert-info col-md-6 col-sm-6 ">-->
              <!--                        <input type="text" id="search" name="search" required="required" class="form-control">-->
              <!--                      </div>-->
              <!--                  </div>-->
              <!--                   <div class="item form-group">-->
              <!--                   <input type="button" value="Search" id="btnSearch" class="btn btn-lg btn-warning" style="width:120px;margin-left:45%">-->
              <!--                   </div>-->
              <!--              </div>-->
                        
              <!--            </div>-->
              <!--        </div>-->
              <!--    </div>-->
              <!--  </div>-->
              <!--</div>-->
                <!--your inserted page ends here-->
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <!--div class="x_panel"-->
                 
                  <div class="x_content">
                  <!--put your page content starts here-->

                  <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                      <h2>MOMO Agents Dashboard</h2>
                    <ul class="nav navbar-right panel_toolbox">
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  
                       <div class="row" style="margin-left:40px">
                   <div class="col-sm-6-6" style="margin-top:30px">
     
                                
                                 <div class="div-square" id="idDailyRecordIcon">
                                  <a href="daily-record" >
                                  <i class="fa fa-calendar fa-5x icon-layout"></i>
                                  <h6>Enter record</h6>
                                  </a>
                                  </div>
           
                     
                  </div>
                     <div class="col-sm-6-6" style="margin-top:30px">
              
                                
                                 <div class="div-square" id="idViewRec">
                                  <a href="daily-record" >
                                  <i class="fa fa-list-alt fa-5x icon-layout"></i>
                                  <h6>View records&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h6>
                                  </a>
                                  </div>
              
                  </div>
              
                           
                        </div>



                </div>





              </div>
            </div>
                </div>
              </div>
                <!--your inserted page ends here-->
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>