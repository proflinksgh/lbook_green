<body class="fixed-nav sticky-footer" id="page-top">
       <input type="hidden" id="rotator" name="rotator" value="34" />
   <div id="clLoad" style="display: none;">
    <div data-loader="circle-side"></div>
   </div>
  <div class="content-wrapper">
    <div class="container-fluid">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="dashboard">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Matured Accounts</li>
      </ol>  
      <div class="card mb-3" id="searchBox">
        <div class="card-header">        
          <i class="fa fa-table"></i> Matured</div>
          <div align="right" style="margin-top:1%">
           <a href="#" class="btn btn-success medium" id="idReactive"><i class="fa fa-pencil-square-o"></i> Rollover</a>    
          </div>
        <div class="card-body shTable">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                    <th><input type="checkbox" name="select_all" value="1" id="example-select-all"></th>
                     <th>Id#</th>
                     <th>Account Number</th>
                     <th>Client</th>
                     <th>Subscription</th>
                     <th>Matured Date</th>
                     <th>Product</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                    <th><input type="checkbox" name="select_all" value="1" id="example-select-all"></th>
                     <th>Id#</th>
                     <th>Account Number</th>
                     <th>Client</th>
                     <th>Subscription</th>
                     <th>Matured Date</th>
                     <th>Product</th>
                </tr>
              </tfoot>
              <tbody>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
</body>




<div class="modal fade" id="modalMatured" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Rollover Account</h5>
            <button class="close clCloseUpdt" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
                      <div class="form-group">
                        <label>Account Name <span style="color:red">*</span></label>
                        <input id="idAccname1" class="form-control" type="text" placeholder= "Account name" disabled="disabled" name="idAccountName">
                      </div>
                      
                       <div class="form-group">
                        <label>Account Number <span style="color:red">*</span></label>
                        <input id="idAccNo1" class="form-control" type="text" placeholder= "Account number" name="idAccountNo" disabled = "disabled">
                      </div>
                      <div class="form-group">
                        <label>Subscription <span style="color:red">*</span></label>
                          <input id="idSubscribed" class="form-control form-rec" type="text" name="idSubscribed" disabled = "disabled">
                      </div>


                      <div class="form-group">
                        <label>Choose New Subscription <span style="color:red">*</span></label>
                          <select id="idNew" class="form-control">
                                    <option disabled="disabled" selected="selected">Select new subscription</option>
                                    <option value="30">  1 Month</option>
                                    <option value="90">  3 Months</option>
                                    <option value="180"> 6 Months</option>
                                    <option value="270"> 9 Months</option>
                                    <option value="360"> 1 Year</option>
                                    <option value="720"> 2 Years</option>
                                    <option value="1080">3 Years</option>
                                </select>
                      </div>
          </div>
          <div class="modal-footer">
            <p><a href="#" class="btn_1 medium" id="btnReactive"><i class="spinner"></i><i class="fa fa-pencil-square-o"></i> Reactivate</a></p>
          </div>
        </div>
      </div>
</div>