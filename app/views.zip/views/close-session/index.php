 
 

 <div class="site-wrapper">

      <div class="site-wrapper-inner">

        <div class="container">

          <div class="masthead clearfix">
            <div class="container inner">
              
              
            </div>
          </div>

          <div class="inner cover">
            <h1 class="cover-heading">L-book session closed</h1>
            <p class="lead">Sorry your L-Book session is currently closed</p>
            <p class="lead">
              <a href="auth" class="btn btn-lg btn-success">Go back</a>
            </p>
          </div>

        </div>

      </div>

    </div>