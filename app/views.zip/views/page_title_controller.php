<?php 

$site_title = '';

if(isset($url_target[0]))
{
	
}
else
{
	$site_title = 'L-book 1.0.0';
}



 ?>