<div class="wrapper">
  <form class="login">
    <p class="title">Product Activation</p>
    <!--<p class="title" style="font-size:14px;margin-top:10px">Enter activation code</p>-->
    <i class="fa fa-key" style="font-size:20px">Enter activation code</i>
    <input type="text" placeholder="Enter product key(xxxxx-xxxxx)" id="code" class="log" name="user"  required="required" value="">
    <button type="button" id="btnActivate">
      <i class="spinner"></i>
      <span class="state">Activate</span>
    </button>
  </form>
  </p>
</div>